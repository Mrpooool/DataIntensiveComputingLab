-- Q3 rebuilt from the air_quality_impact_summary product. Hourly NYC demand comes from the
-- product; the calendar and the two-level PM2.5 median are the canonical definitions.
WITH calendar_hours AS (
    SELECT EXPLODE(
        CASE WHEN first_hour < end_hour_exclusive
             THEN SEQUENCE(first_hour, end_hour_exclusive - INTERVAL 1 HOUR, INTERVAL 1 HOUR)
             ELSE ARRAY()
        END
    ) AS pickup_hour_utc
    FROM (
        SELECT
            {calendar_first_hour} AS first_hour,
            {calendar_end_hour_exclusive} AS end_hour_exclusive
    )
),
hourly_demand AS (
    SELECT pickup_hour_utc, trip_count
    FROM {product_view}
    WHERE {trip_filter}
),
site_hour_pm25 AS (
    SELECT
        site_id,
        air_quality_hour_utc,
        MEDIAN(measurement_value) AS site_pm25
    FROM {air_quality_view}
    WHERE parameter_code = '88101'
      AND measurement_unit = 'Micrograms/cubic meter (LC)'
      AND method_type = 'FEM'
      AND method_code = '636'
    GROUP BY site_id, air_quality_hour_utc
),
hourly_pm25 AS (
    SELECT
        air_quality_hour_utc,
        MEDIAN(site_pm25) AS air_quality_pm25
    FROM site_hour_pm25
    GROUP BY air_quality_hour_utc
),
hourly_analysis AS (
    SELECT
        hours.pickup_hour_utc,
        COALESCE(demand.trip_count, 0) AS trip_count,
        pm25.air_quality_pm25
    FROM calendar_hours AS hours
    LEFT JOIN hourly_demand AS demand USING (pickup_hour_utc)
    LEFT JOIN hourly_pm25 AS pm25
      ON hours.pickup_hour_utc = pm25.air_quality_hour_utc
),
classified AS (
    SELECT *, {pm25_case} AS pm25_band
    FROM hourly_analysis
),
overall AS (
    SELECT CORR(air_quality_pm25, trip_count) AS overall_pm25_demand_correlation
    FROM classified
    WHERE air_quality_pm25 IS NOT NULL
)
SELECT
    pm25_band,
    COUNT(*) AS hour_count,
    SUM(trip_count) AS total_trip_count,
    AVG(trip_count) AS average_hourly_trip_count,
    AVG(air_quality_pm25) AS average_pm25,
    MAX(overall.overall_pm25_demand_correlation) AS overall_pm25_demand_correlation
FROM classified
CROSS JOIN overall
GROUP BY pm25_band
ORDER BY MIN(air_quality_pm25), pm25_band
